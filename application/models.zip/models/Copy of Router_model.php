<?php

class Router_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }
	public function server($id=false) {
        $response = false;

        if ($id) {
            $query = $this->db->get_where('gm_server', array('id' => $id));
            $response = $query->row_array();
        } else {
            $query = $this->db->get('gm_server');
            $response = $query->result_array();
        }

        return $response;
    }
	
	public function serverROW() {
        $response = false;

            $query = $this->db->get('gm_server');
            $response = $query->row_array();

        return $response;
    }
	
	public function count() {
        return $this->db->get('gm_server')->num_rows();
    }
	
    public function get($id=false) {
        $response = false;

        if ($id) {
            $query = $this->db->get_where('gm_router', array('id' => $id));
            $response = $query->row_array();
        } else {
            $query = $this->db->get('gm_router');
            $response = $query->result_array();
        }

        return $response;
    }

    public function simpan() {
        $data = array(
            'nama' => $this->input->post('nama'),
			'ip' => $this->input->post('ip'),
			'user' => $this->input->post('user'),
			'pass' => $this->input->post('pass'),
			'mon' => $this->input->post('mon'),
        );
		$routerid = $this->serverROW();
		$hostname = $routerid['ip'];
		$username = $routerid['user'];
		$password = $routerid['pass'];
		if($this->input->post('mon') == "1") {$mon = "no";} else { $mon = "yes"; }					
					
		if ($this->routerosapi->connect($hostname, $username, $password))
			{
				$this->routerosapi->write('/tool/netwatch/add',false);				
				$this->routerosapi->write('=host='.$this->input->post('ip'), false);							
				$this->routerosapi->write('=interval=00:05:00', false);
				$this->routerosapi->write('=timeout=300', false);     				
				$this->routerosapi->write('=comment='.$this->input->post('nama'), false);
				$this->routerosapi->write('=up-script='.":global waktu ([/system clock get time]); /tool fetch url=\"https://api.telegram.org/bot1117257670:AAH7lYHPWHH6ltmoflhj0FJdPsneA9wyRLE/sendMessage\?chat_id=-469036792&text=Time: ".'$waktu'." Service Ping on ".$this->input->post('nama')." (".$this->input->post('ip').") is now up (ok)\" keep-result=no", false);			
				$this->routerosapi->write('=down-script='.":global waktu ([/system clock get time]); /tool fetch url=\"https://api.telegram.org/bot1117257670:AAH7lYHPWHH6ltmoflhj0FJdPsneA9wyRLE/sendMessage\?chat_id=-469036792&text=Time: ".'$waktu'." Service Ping on ".$this->input->post('nama')." (".$this->input->post('ip').") is now down (timeout)\" keep-result=no", false);	
				$this->routerosapi->write('=disabled='.$mon);				
				$this->routerosapi->read();
				$this->routerosapi->disconnect();	
				$this->session->set_flashdata('message','Data berhasil ditambahkan!');
			}
			else
			{
				$this->session->set_flashdata('message', 'Login gagal. Pastikan hostname, username dan password yang Anda masukkan benar!');
			}	

        return $this->db->insert('gm_router', $data);
    }

    public function timpa($id) {
        $data = array(
            'nama' => $this->input->post('nama'),
			'ip' => $this->input->post('ip'),
			'user' => $this->input->post('user'),
			'pass' => $this->input->post('pass'),
			'mon' => $this->input->post('mon'),
        );
		$router = $this->get($id);
		$routerid = $this->serverROW();
		$hostname = $routerid['ip'];
		$username = $routerid['user'];
		$password = $routerid['pass'];
		if($this->input->post('mon') == "1") {$mon = "no";} else { $mon = "yes"; }
		
		if ($this->routerosapi->connect($hostname, $username, $password))
			{
				$this->routerosapi->write("/tool/netwatch/print", false);			
				$this->routerosapi->write("=.proplist=.id", false);		
				$this->routerosapi->write("?comment=".$router['nama']);				
				$APInetwatch = $this->routerosapi->read();
				foreach ($APInetwatch as $netwatch)
				{
					$id_router = $netwatch['.id'];
				}
				$this->routerosapi->write('/tool/netwatch/set',false);
				$this->routerosapi->write('=disabled='.$mon,false);
				$this->routerosapi->write('=.id='.$id_router);
				$this->routerosapi->read();
				$this->routerosapi->disconnect();	
			}
			else
			{
				$this->session->set_flashdata('message', 'Login gagal !');
			}
		
        $this->db->where('id', $id);

        return $this->db->update('gm_router', $data);
    }

    public function delete($id) {
		$router = $this->get($id);
		$routerid = $this->serverROW();
		$hostname = $routerid['ip'];
		$username = $routerid['user'];
		$password = $routerid['pass'];
			
		if ($this->routerosapi->connect($hostname, $username, $password))
			{
				$this->routerosapi->write("/tool/netwatch/print", false);			
				$this->routerosapi->write("=.proplist=.id", false);		
				$this->routerosapi->write("?comment=".$router['nama']);				
				$APInetwatch = $this->routerosapi->read();
				foreach ($APInetwatch as $netwatch)
				{
					$id_router = $netwatch['.id'];
				}
				$this->routerosapi->write('/tool/netwatch/remove',false);
				$this->routerosapi->write('=.id='.$id_router);
				$this->routerosapi->read();
				$this->routerosapi->disconnect();	
			}
			else
			{
				$this->session->set_flashdata('message', 'Login gagal !');
			}
        return $this->db->delete('gm_router', array('id' => $id));

        return false;
    }
	
	
	
	//SERVER
	public function simpan_server() {
        $data = array(
            'nama' => $this->input->post('nama'),
			'ip' => $this->input->post('ip'),
			'user' => $this->input->post('user'),
			'pass' => $this->input->post('pass'),
        );
		
        return $this->db->insert('gm_server', $data);
    }

    public function timpa_server($id) {
        $data = array(
            'nama' => $this->input->post('nama'),
			'ip' => $this->input->post('ip'),
			'user' => $this->input->post('user'),
			'pass' => $this->input->post('pass'),
        );

        $this->db->where('id', $id);

        return $this->db->update('gm_server', $data);
    }

    public function delete_server($id) {
        return $this->db->delete('gm_server', array('id' => $id));

        return false;
    }
}
