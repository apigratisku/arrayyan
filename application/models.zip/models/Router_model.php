<?php

class Router_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }
	public function server($id=false) {
        $response = false;

        if ($id) {
            $query = $this->db->get_where('gm_server', array('id' => $id));
            $response = $query->row_array();
        } else {
            $query = $this->db->get('gm_server');
            $response = $query->result_array();
        }

        return $response;
    }
	
	
	
	public function serverROW() {
        $response = false;

            $query = $this->db->get('gm_server');
            $response = $query->row_array();

        return $response;
    }
	
	
    public function get($id=false) {
        $response = false;

        if ($id) {
            $query = $this->db->get_where('gm_router', array('id' => $id));
            $response = $query->row_array();
        } else {
            $this->db->select('*');
            $this->db->from('gm_router');
			$this->db->order_by("nama", "asc");
            $query = $this->db->get();
            $response = $query->result_array();
        }

        return $response;
    }
	
	public function count() {
		if($this->session->userdata('ses_admin') == "1")
		{
        return $this->db->get('gm_router')->num_rows();
		}
		else
		{
		return $this->db->get_where('gm_router', array('id' => $this->session->userdata('idrouter')))->num_rows();
		}
    }
	
	public function router_up() {
		if($this->session->userdata('ses_admin') == "1")
		{
        return $this->db->get_where('gm_router', array('up_down' => "1"))->num_rows();
		}
		else
		{
		return $this->db->get_where('gm_router', array('id' => $this->session->userdata('idrouter'),'up_down' => "1"))->num_rows();
		}
    }
	
	public function router_down() {
		if($this->session->userdata('ses_admin') == "1")
		{
        return $this->db->get_where('gm_router', array('up_down' => "0"))->num_rows();
		}
		else
		{
		return $this->db->get_where('gm_router', array('id' => $this->session->userdata('idrouter'),'up_down' => "0"))->num_rows();
		}
    }

//SERVER
	public function simpan_server() {
		//ENKRIPSI PASSWORD ROUTER
		require_once APPPATH."third_party/addon.php";
		$ar_chip 	 = new Cipher(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
		$ar_rand 	 = "%^$%^&%*GMEDIA%^$%^&%*";
		$ar_str_user = $this->input->post('user');
		$ar_enc_user = $ar_chip->encrypt($ar_str_user, $ar_rand);
		$ar_str_pass = $this->input->post('pass');
		$ar_enc_pass = $ar_chip->encrypt($ar_str_pass, $ar_rand);
        $data = array(
            'nama' => $this->input->post('nama'),
			'ip' => $this->input->post('ip'),
			'user' => $ar_enc_user,
			'pass' => $ar_enc_pass,
			'ip_aplikasi' => $this->input->post('ip_aplikasi'),
        );
		$this->db->insert('gm_server', $data);
		
		$hostname = $this->input->post('ip');
		$username = $this->input->post('user');
		$password = $this->input->post('pass');
		$aplikasi = $this->input->post('ip_aplikasi');
		if ($this->routerosapi->connect($hostname, $username, $password))
			{
				$this->routerosapi->write("/tool/netwatch/print", false);			
				$this->routerosapi->write("=.proplist=.id", false);		
				$this->routerosapi->write("?comment=MTR-PROJECT");				
				$APInetwatch = $this->routerosapi->read();
				foreach ($APInetwatch as $netwatch)
				{
					$id_router = $netwatch['.id'];
				}
				if(isset($id_router))
				{
				$this->routerosapi->write('/tool/netwatch/remove',false);
				$this->routerosapi->write('=.id='.$id_router);
				$this->routerosapi->read();
				}
				else
				{
				$this->routerosapi->write('/tool/netwatch/add',false);				
				$this->routerosapi->write('=host='.$this->input->post('ip'), false);							
				$this->routerosapi->write('=interval=00:00:10', false);
				$this->routerosapi->write('=timeout=10', false);     				
				$this->routerosapi->write('=comment=MTR-PROJECT', false);
				$this->routerosapi->write('=up-script='."/tool fetch url=\"https://".$aplikasi."/xdark/update2.php?IPclient=".$hostname."&status=1\" keep-result=no", false);			
				$this->routerosapi->write('=down-script='."/tool fetch url=\"https://".$aplikasi."/xdark/update2.php?IPclient=".$hostname."&status=0\" keep-result=no", false);		
				$this->routerosapi->write('=disabled=no');				
				$this->routerosapi->read();
				}
				$this->routerosapi->disconnect();		
			}
			else
			{
				$this->session->set_flashdata('error', 'Login gagal !');
			}
        return $this->session->set_flashdata('success','Data berhasil ditambahkan!');
    }

    public function timpa_server($id) {
        //ENKRIPSI PASSWORD ROUTER
		require_once APPPATH."third_party/addon.php";
		$ar_chip 	 = new Cipher(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
		$ar_rand 	 = "%^$%^&%*GMEDIA%^$%^&%*";
		$ar_str_user = $this->input->post('user');
		$ar_enc_user = $ar_chip->encrypt($ar_str_user, $ar_rand);
		$ar_str_pass = $this->input->post('pass');
		$ar_enc_pass = $ar_chip->encrypt($ar_str_pass, $ar_rand);
        $data = array(
            'nama' => $this->input->post('nama'),
			'ip' => $this->input->post('ip'),
			'user' => $ar_enc_user,
			'pass' => $ar_enc_pass,
			'ip_aplikasi' => $this->input->post('ip_aplikasi'),
		);
		$this->db->where('id', $id);
		$this->db->update('gm_server', $data);
		
		$hostname = $this->input->post('ip');
		$username = $this->input->post('user');
		$password = $this->input->post('pass');
		$aplikasi = $this->input->post('ip_aplikasi');
		if ($this->routerosapi->connect($hostname, $username, $password))
			{
				$this->routerosapi->write("/tool/netwatch/print", false);			
				$this->routerosapi->write("=.proplist=.id", false);		
				$this->routerosapi->write("?comment=MTR-PROJECT");				
				$APInetwatch = $this->routerosapi->read();
				foreach ($APInetwatch as $netwatch)
				{
					$id_router = $netwatch['.id'];
				}
				if(isset($id_router))
				{
				$this->routerosapi->write('/tool/netwatch/remove',false);
				$this->routerosapi->write('=.id='.$id_router);
				$this->routerosapi->read();
				}
				else
				{
				$this->routerosapi->write('/tool/netwatch/add',false);				
				$this->routerosapi->write('=host='.$this->input->post('ip'), false);							
				$this->routerosapi->write('=interval=00:00:10', false);
				$this->routerosapi->write('=timeout=10', false);     				
				$this->routerosapi->write('=comment=MTR-PROJECT', false);
				$this->routerosapi->write('=up-script='."/tool fetch url=\"https://".$aplikasi."/xdark/update2.php?IPclient=".$hostname."&status=1\" keep-result=no", false);			
				$this->routerosapi->write('=down-script='."/tool fetch url=\"https://".$aplikasi."/xdark/update2.php?IPclient=".$hostname."&status=0\" keep-result=no", false);		
				$this->routerosapi->write('=disabled=no');				
				$this->routerosapi->read();
				}
				$this->routerosapi->disconnect();	
			}
			else
			{
				$this->session->set_flashdata('error', 'Login gagal !');
			}
        return $this->session->set_flashdata('success','Data berhasil ditambahkan!'); 
        
    }

    public function delete_server($id) {
		$routerid = $this->server($id);
		
		$hostname = $routerid['ip'];
		$username = $routerid['user'];
		$password = $routerid['pass'];
		$aplikasi = $routerid['ip_aplikasi'];
		if ($this->routerosapi->connect($hostname, $username, $password))
			{
				$this->routerosapi->write("/tool/netwatch/print", false);			
				$this->routerosapi->write("=.proplist=.id", false);		
				$this->routerosapi->write("?comment=MTR-PROJECT");				
				$APInetwatch = $this->routerosapi->read();
				foreach ($APInetwatch as $netwatch)
				{
					$id_router = $netwatch['.id'];
				}
				if(isset($id_router))
				{
				$this->routerosapi->write('/tool/netwatch/remove',false);
				$this->routerosapi->write('=.id='.$id_router);
				$this->routerosapi->read();
				}
				$this->routerosapi->disconnect();	
			}
			else
			{
				$this->session->set_flashdata('error', 'Login gagal !');
			} 
        return $this->db->delete('gm_server', array('id' => $id));
    }
	
//ROUTER
    public function simpan() {
		//ENKRIPSI PASSWORD ROUTER
		require_once APPPATH."third_party/addon.php";
		$ar_chip 	 = new Cipher(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
		$ar_rand 	 = "%^$%^&%*GMEDIA%^$%^&%*";
		$ar_str_user = $this->input->post('user');
		$ar_enc_user = $ar_chip->encrypt($ar_str_user, $ar_rand);
		$ar_str_pass = $this->input->post('pass');
		$ar_enc_pass = $ar_chip->encrypt($ar_str_pass, $ar_rand);
        $data = array(
            'nama' => $this->input->post('nama'),
			'ip' => $this->input->post('ip'),
			'user' => $ar_enc_user,
			'pass' => $ar_enc_pass,
			'mon' => $this->input->post('mon'),
			'lastmile' => $this->input->post('lastmile'),
			'network' => $this->input->post('network'),
        );
		$this->db->insert('gm_router', $data);
		
		$routerid = $this->serverROW();
		
		//ENKRIPSI PASSWORD ROUTER
		require_once APPPATH."third_party/addon.php";
		$ar_chip 	 = new Cipher(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
		$ar_rand 	 = "%^$%^&%*GMEDIA%^$%^&%*";
		$ar_str_user = $routerid['user'];
		$ar_dec_user = $ar_chip->decrypt($ar_str_user, $ar_rand);
		$ar_str_pass = $routerid['pass'];
		$ar_dec_pass = $ar_chip->decrypt($ar_str_pass, $ar_rand);
		$hostname = $routerid['ip'];
		$username = $ar_dec_user;
		$password = $ar_dec_pass;
		$aplikasi = $routerid['ip_aplikasi'];
		if($this->input->post('mon') == "1") {$mon = "no";} else { $mon = "yes"; }					
					
		if ($this->routerosapi->connect($hostname, $username, $password))
			{
				$RO = "RO-".$this->input->post('nama');
				$LL = "LL-".$this->input->post('nama');
				$this->routerosapi->write('/system/scheduler/add',false);				
				$this->routerosapi->write('=name='.$RO, false);							
				$this->routerosapi->write('=interval=00:00:03', false);     				
				$this->routerosapi->write('=start-time=startup', false); 
				$this->routerosapi->write('=on-event='
				." :local addr ".$this->input->post('ip').";"
				." :local pin;"
				." :local pout;"
				." /tool flood-ping ".'$addr'." count=10 do={"
				." :if (".'$sent'." = 10) do={"
				." :set pout ".'$sent'.";"
				." :set pin ".'$received'.";"
				." :local ploss (100 - ((".'$pin'." * 100) / ".'$pout'."));"
				." :if (".'$ploss'." >= 100) do={"
				." :if ([:len [/file find name~\"".$RO.".txt\"]] < 1) do={"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPclient=".$this->input->post('ip')."&status=0\" keep-result=no;"
				." /file print file=\"".$RO."\";"
				."}} else={ /file remove \"".$RO.".txt\";"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPclient=".$this->input->post('ip')."&status=1\" keep-result=no;"
				."}}}", false);								
				$this->routerosapi->write('=disabled='.$mon);				
				$this->routerosapi->read();
				
				$this->routerosapi->write('/system/scheduler/add',false);				
				$this->routerosapi->write('=name='.$LL, false);							
				$this->routerosapi->write('=interval=00:00:03', false);     				
				$this->routerosapi->write('=start-time=startup', false); 
				$this->routerosapi->write('=on-event='
				." :local addr ".$this->input->post('lastmile').";"
				." :local pin;"
				." :local pout;"
				." /tool flood-ping ".'$addr'." count=10 do={"
				." :if (".'$sent'." = 10) do={"
				." :set pout ".'$sent'.";"
				." :set pin ".'$received'.";"
				." :local ploss (100 - ((".'$pin'." * 100) / ".'$pout'."));"
				." :if (".'$ploss'." >= 100) do={"
				." :if ([:len [/file find name~\"".$LL.".txt\"]] < 1) do={"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPlastmile=".$this->input->post('lastmile')."&status=0\" keep-result=no;"
				." /file print file=\"".$LL."\";"
				."}} else={ /file remove \"".$LL.".txt\";"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPlastmile=".$this->input->post('lastmile')."&status=1\" keep-result=no;"
				."}}}", false);								
				$this->routerosapi->write('=disabled=no');				
				$this->routerosapi->read();
				
				$this->routerosapi->disconnect();			
			}
			else
			{
				$this->session->set_flashdata('error', 'Login gagal. Pastikan hostname, username dan password yang Anda masukkan benar!');
			}	

        return $this->session->set_flashdata('success','Data berhasil ditambahkan!');
    }

    public function timpa($id) {
		//ENKRIPSI PASSWORD ROUTER
		require_once APPPATH."third_party/addon.php";
		$ar_chip 	 = new Cipher(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
		$ar_rand 	 = "%^$%^&%*GMEDIA%^$%^&%*";
		$ar_str_user = $this->input->post('user');
		$ar_enc_user = $ar_chip->encrypt($ar_str_user, $ar_rand);
		$ar_str_pass = $this->input->post('pass');
		$ar_enc_pass = $ar_chip->encrypt($ar_str_pass, $ar_rand);
		 
        $data = array(
            'nama' => $this->input->post('nama'),
			'ip' => $this->input->post('ip'),
			'user' => $ar_enc_user,
			'pass' => $ar_enc_pass,
			'mon' => $this->input->post('mon'),
			'lastmile' => $this->input->post('lastmile'),
			'network' => $this->input->post('network'),
        );
		$this->db->where('id', $id);
		$this->db->update('gm_router', $data);
		
		$router = $this->get($id);
		$routerid = $this->serverROW();
		//ENKRIPSI PASSWORD ROUTER
		require_once APPPATH."third_party/addon.php";
		$ar_chip 	 = new Cipher(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
		$ar_rand 	 = "%^$%^&%*GMEDIA%^$%^&%*";
		$ar_str_user = $routerid['user'];
		$ar_dec_user = $ar_chip->decrypt($ar_str_user, $ar_rand);
		$ar_str_pass = $routerid['pass'];
		$ar_dec_pass = $ar_chip->decrypt($ar_str_pass, $ar_rand);
		$hostname = $routerid['ip'];
		$username = $ar_dec_user;
		$password = $ar_dec_pass;
		if($this->input->post('mon') == "1") {$mon = "no";} else { $mon = "yes"; }
		$RO = "RO-".$router['nama'];
		$LL = "LL-".$router['nama'];
		$RO_UPDATE = "RO-".$this->input->post('nama');
		$LL_UPDATE = "LL-".$this->input->post('nama');
		$aplikasi = $routerid['ip_aplikasi'];
		if ($this->routerosapi->connect($hostname, $username, $password))
			{
				//RO
				$this->routerosapi->write('/system/scheduler/print',false);				
				$this->routerosapi->write("=.proplist=name", false);	
				$this->routerosapi->write("=.proplist=.id", false);						
				$this->routerosapi->write("?name=".$RO);			
				$API_RO = $this->routerosapi->read();
				foreach ($API_RO as $ROW_RO)
				{
					$D_RO = $ROW_RO['.id'];
				}
				if(isset($D_RO))
				{
				$this->routerosapi->write('/system/scheduler/set',false);				
				$this->routerosapi->write('=name='.$RO_UPDATE, false);							
				$this->routerosapi->write('=interval=00:00:03', false);     				
				$this->routerosapi->write('=start-time=startup', false); 
				$this->routerosapi->write('=on-event='
				." :local addr ".$this->input->post('ip').";"
				." :local pin;"
				." :local pout;"
				." /tool flood-ping ".'$addr'." count=10 do={"
				." :if (".'$sent'." = 10) do={"
				." :set pout ".'$sent'.";"
				." :set pin ".'$received'.";"
				." :local ploss (100 - ((".'$pin'." * 100) / ".'$pout'."));"
				." :if (".'$ploss'." >= 100) do={"
				." :if ([:len [/file find name~\"".$RO.".txt\"]] < 1) do={"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPclient=".$this->input->post('ip')."&status=0\" keep-result=no;"
				." /file print file=\"".$RO."\";"
				."}} else={ /file remove \"".$RO.".txt\";"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPclient=".$this->input->post('ip')."&status=1\" keep-result=no;"
				."}}}", false);								
				$this->routerosapi->write('=disabled='.$mon, false);
				$this->routerosapi->write('=.id='.$D_RO);				
				$this->routerosapi->read();
				}
				
				//LL
				$this->routerosapi->write('/system/scheduler/print',false);				
				$this->routerosapi->write("=.proplist=name", false);	
				$this->routerosapi->write("=.proplist=.id", false);						
				$this->routerosapi->write("?name=".$LL);			
				$API_LL = $this->routerosapi->read();
				foreach ($API_LL as $ROW_LL)
				{
					$L_RO = $ROW_LL['.id'];
				}
				if(isset($L_RO))
				{
				$this->routerosapi->write('/system/scheduler/set',false);				
				$this->routerosapi->write('=name='.$LL_UPDATE, false);							
				$this->routerosapi->write('=interval=00:00:03', false);     				
				$this->routerosapi->write('=start-time=startup', false); 
				$this->routerosapi->write('=on-event='
				." :local addr ".$this->input->post('lastmile').";"
				." :local pin;"
				." :local pout;"
				." /tool flood-ping ".'$addr'." count=10 do={"
				." :if (".'$sent'." = 10) do={"
				." :set pout ".'$sent'.";"
				." :set pin ".'$received'.";"
				." :local ploss (100 - ((".'$pin'." * 100) / ".'$pout'."));"
				." :if (".'$ploss'." >= 100) do={"
				." :if ([:len [/file find name~\"".$LL.".txt\"]] < 1) do={"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPlastmile=".$this->input->post('lastmile')."&status=0\" keep-result=no;"
				." /file print file=\"".$LL."\";"
				."}} else={ /file remove \"".$LL.".txt\";"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPlastmile=".$this->input->post('lastmile')."&status=1\" keep-result=no;"
				."}}}", false);									
				$this->routerosapi->write('=disabled='.$mon, false);
				$this->routerosapi->write('=.id='.$L_RO);				
				$this->routerosapi->read();
				}
				$this->routerosapi->disconnect();	
			}
			else
			{
				$this->session->set_flashdata('error', 'Login gagal !');
			}
		
        return $this->session->set_flashdata('success', 'Berhasil mengubah data.'); 
    }

    public function delete($id) {
	
		//HAPUS SCHEDULER ROUTER
		$router = $this->get($id);
		$routerid = $this->serverROW();
		$RO = "RO-".$router['nama'];
		$LL = "LL-".$router['nama'];
		//ENKRIPSI PASSWORD ROUTER
		require_once APPPATH."third_party/addon.php";
		$ar_chip 	 = new Cipher(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
		$ar_rand 	 = "%^$%^&%*GMEDIA%^$%^&%*";
		$ar_str_user = $router['user'];
		$ar_dec_user = $ar_chip->decrypt($ar_str_user, $ar_rand);
		$ar_str_pass = $router['pass'];
		$ar_dec_pass = $ar_chip->decrypt($ar_str_pass, $ar_rand);
		
		$ar_srv_user = $routerid['user'];
		$ar_dec_suser = $ar_chip->decrypt($ar_srv_user, $ar_rand);
		$ar_srv_pass = $routerid['pass'];
		$ar_dec_spass = $ar_chip->decrypt($ar_srv_pass, $ar_rand);
		
		$hostname1 = $router['ip'];
		$username1 = $ar_dec_user;
		$password1 = $ar_dec_pass;
		
		$hostname2 = $routerid['ip'];
		$username2 = $ar_dec_suser;
		$password2 = $ar_dec_spass;
			
			//REMOVE SCHEDULER DARI ROUTER SERVER
			if ($this->routerosapi->connect($hostname2, $username2, $password2))
			{
				//RO
				$this->routerosapi->write('/system/scheduler/print',false);				
				$this->routerosapi->write("=.proplist=name", false);	
				$this->routerosapi->write("=.proplist=.id", false);						
				$this->routerosapi->write("?name=".$RO);			
				$API_RO = $this->routerosapi->read();
				foreach ($API_RO as $ROW_RO)
				{
					$D_RO = $ROW_RO['.id'];
				}
				if(isset($D_RO))
				{
				$this->routerosapi->write('/system/scheduler/remove',false);
				$this->routerosapi->write('=.id='.$D_RO);
				$this->routerosapi->read();
				}
				
				//LL
				$this->routerosapi->write('/system/scheduler/print',false);				
				$this->routerosapi->write("=.proplist=name", false);	
				$this->routerosapi->write("=.proplist=.id", false);						
				$this->routerosapi->write("?name=".$LL);			
				$API_LL = $this->routerosapi->read();
				foreach ($API_LL as $ROW_LL)
				{
					$L_RO = $ROW_LL['.id'];
				}
				if(isset($L_RO))
				{
				$this->routerosapi->write('/system/scheduler/remove',false);
				$this->routerosapi->write('=.id='.$L_RO);
				$this->routerosapi->read();
				}
				$this->routerosapi->disconnect();	
			}
			else
			{
				$this->session->set_flashdata('error', 'Login gagal !');
			}
			
			//REMOVE NETWATCH DARI ROUTER CLIENT
			if ($this->routerosapi->connect($hostname2, $username2, $password2))
			{
				$this->routerosapi->write("/tool/netwatch/print", false);			
				$this->routerosapi->write("=.proplist=.id", false);		
				$this->routerosapi->write("?comment=".$router['nama']);				
				$APInetwatch = $this->routerosapi->read();
				foreach ($APInetwatch as $netwatch)
				{
					$id_router = $netwatch['.id'];
				}
				if(isset($id_router))
				{
				$this->routerosapi->write('/tool/netwatch/remove',false);
				$this->routerosapi->write('=.id='.$id_router);
				$this->routerosapi->read();
				}
				
				$this->routerosapi->write("/tool/netwatch/print", false);			
				$this->routerosapi->write("=.proplist=.id", false);		
				$this->routerosapi->write("?comment=".$router['nama']." - LASTMILE");				
				$APInetwatch = $this->routerosapi->read();
				foreach ($APInetwatch as $netwatch)
				{
					$id_router = $netwatch['.id'];
				}
				if(isset($id_router))
				{
				$this->routerosapi->write('/tool/netwatch/remove',false);
				$this->routerosapi->write('=.id='.$id_router);
				$this->routerosapi->read();
				}
				$this->routerosapi->disconnect();	
			}
			else
			{
				$this->session->set_flashdata('error', 'Login gagal !');
			}
		//HAPUS DATA DARI DATABASE SECARA BERURUTAN	
		$exe1 = $this->db->delete('gm_log', array('idrouter' => $id));
		$exe2 = $this->db->delete('gm_operator', array('idrouter' => $id));	
		$exe3 = $this->db->delete('gm_lokalan', array('idrouter' => $id));
		$exe4 = $this->db->delete('gm_router', array('id' => $id));
		
		if($exe1 && $exe2 && $exe3 && $exe4)
		{
        return $this->session->set_flashdata('success', 'Berhasil mengubah data.'); 
		}
		else
		{
		return $this->session->set_flashdata('error', 'Gagal menghapus data.');
		} 
    }
	
		//TEMPORER MIGRASI KE SHCEDULER
		public function simpan_temporer() {
		$routerid = $this->serverROW();
		$router = $this->get();
		//ENKRIPSI PASSWORD ROUTER
		require_once APPPATH."third_party/addon.php";
		$ar_chip 	 = new Cipher(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
		$ar_rand 	 = "%^$%^&%*GMEDIA%^$%^&%*";
		$ar_str_user = $routerid['user'];
		$ar_dec_user = $ar_chip->decrypt($ar_str_user, $ar_rand);
		$ar_str_pass = $routerid['pass'];
		$ar_dec_pass = $ar_chip->decrypt($ar_str_pass, $ar_rand);
		$hostname = $routerid['ip'];
		$username = $ar_dec_user;
		$password = $ar_dec_pass;
		$aplikasi = $routerid['ip_aplikasi'];
						
					
			if ($this->routerosapi->connect($hostname, $username, $password))
			{
				$router = $this->get();
				$interval = 1;
				foreach($router as $ro)
				{
				
				if($interval <=10)
				{$interval_in = "00:00:03";}elseif($interval <=20)
				{$interval_in = "00:00:06";}elseif($interval <=30)
				{$interval_in = "00:00:09";}elseif($interval <=40)
				{$interval_in = "00:00:12";}elseif($interval <=50)
				{$interval_in = "00:00:15";}elseif($interval <=70)
				{$interval_in = "00:00:18";}elseif($interval <=80)
				{$interval_in = "00:00:21";}elseif($interval <=90)
				{$interval_in = "00:00:24";}elseif($interval <=100)
				{$interval_in = "00:00:27";}elseif($interval <=110)
				{$interval_in = "00:00:30";}elseif($interval <=120)
				{$interval_in = "00:00:33";}elseif($interval <=130)
				{$interval_in = "00:00:36";}elseif($interval <=140)
				{$interval_in = "00:00:39";}elseif($interval <=150)
				{$interval_in = "00:00:42";}elseif($interval <=160)
				{$interval_in = "00:00:45";} 
				$RO = "RO-".$ro['nama'];
				$LL = "LL-".$ro['nama'];
				$this->routerosapi->write('/system/scheduler/add',false);				
				$this->routerosapi->write('=name='.$RO, false);							
				$this->routerosapi->write('=interval='.$interval_in, false);     				
				$this->routerosapi->write('=start-time=startup', false); 
				$this->routerosapi->write('=on-event='
				." :local addr ".$ro['ip'].";"
				." :local pin;"
				." :local pout;"
				." /tool flood-ping ".'$addr'." count=10 do={"
				." :if (".'$sent'." = 10) do={"
				." :set pout ".'$sent'.";"
				." :set pin ".'$received'.";"
				." :local ploss (100 - ((".'$pin'." * 100) / ".'$pout'."));"
				." :if (".'$ploss'." >= 100) do={"
				." :if ([:len [/file find name~\"".$RO.".txt\"]] < 1) do={"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPclient=".$ro['ip']."&status=0\" keep-result=no;"
				." /file print file=\"".$RO."\";"
				."}} else={ /file remove \"".$RO.".txt\";"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPclient=".$ro['ip']."&status=1\" keep-result=no;"
				."}}}", false);								
				$this->routerosapi->write('=disabled=no');				
				$this->routerosapi->read();
				$this->routerosapi->write('/system/scheduler/add',false);				
				$this->routerosapi->write('=name='.$LL, false);							
				$this->routerosapi->write('=interval='.$interval_in, false);     				
				$this->routerosapi->write('=start-time=startup', false); 
				$this->routerosapi->write('=on-event='
				." :local addr ".$ro['lastmile'].";"
				." :local pin;"
				." :local pout;"
				." /tool flood-ping ".'$addr'." count=10 do={"
				." :if (".'$sent'." = 10) do={"
				." :set pout ".'$sent'.";"
				." :set pin ".'$received'.";"
				." :local ploss (100 - ((".'$pin'." * 100) / ".'$pout'."));"
				." :if (".'$ploss'." >= 100) do={"
				." :if ([:len [/file find name~\"".$LL.".txt\"]] < 1) do={"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPlastmile=".$ro['lastmile']."&status=0\" keep-result=no;"
				." /file print file=\"".$LL."\";"
				."}} else={ /file remove \"".$LL.".txt\";"
				." /tool fetch url=\"https://".$aplikasi."/xdark/update.php?IPlastmile=".$ro['lastmile']."&status=1\" keep-result=no;"
				."}}}", false);								
				$this->routerosapi->write('=disabled=no');				
				$this->routerosapi->read();
				$interval++;
			}
				
				$this->routerosapi->disconnect();			
			}
			else
			{
				$this->session->set_flashdata('error', 'Login gagal. Pastikan hostname, username dan password yang Anda masukkan benar!');
			}	

        return $this->session->set_flashdata('success','Data berhasil ditambahkan!');
    }
	

//END	
}
